@extends('crudbooster::admin_template')
@section('content')

    <div>

        @if(CRUDBooster::getCurrentMethod() != 'getProfile' && $button_cancel)
            @if(g('return_url'))
                <p><a title='Return' href='{{g("return_url")}}'><i class='fa fa-chevron-circle-left '></i>
                        &nbsp; {{trans("crudbooster.form_back_to_list",['module'=>CRUDBooster::getCurrentModule()->name])}}
                    </a></p>
            @else
                <p><a title='Main Module' href='{{CRUDBooster::mainpath()}}'><i class='fa fa-chevron-circle-left '></i>
                        &nbsp; {{trans("crudbooster.form_back_to_list",['module'=>CRUDBooster::getCurrentModule()->name])}}
                    </a></p>
            @endif
        @endif

        <div class="panel panel-default">
            <div class="panel-heading">
                <strong><i class='{{CRUDBooster::getCurrentModule()->icon}}'></i> {!! $page_title or "Page Title" !!}
                </strong>
            </div>

            <div class="panel-body" style="padding:20px 0px 0px 0px">
                <?php
                $action = (@$row) ? CRUDBooster::mainpath("edit-save/$row->id") : CRUDBooster::mainpath("add-save");
                $return_url = ($return_url) ?: g('return_url');
                ?>
                <form class='form-horizontal' method='post' id="form" enctype="multipart/form-data"
                      action='{{$action}}'>
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                    <input type='hidden' name='return_url' value='{{ @$return_url }}'/>
                    <input type='hidden' name='ref_mainpath' value='{{ CRUDBooster::mainpath() }}'/>
                    <input type='hidden' name='ref_parameter' value='{{urldecode(http_build_query(@$_GET))}}'/>
                    @if($hide_form)
                        <input type="hidden" name="hide_form" value='{!! serialize($hide_form) !!}'>
                    @endif
                    <div class="box-body" id="parent-form-area">
                        <div class="form-group header-group-0 " id="form-group-name" style="">
                            <label class="control-label col-sm-2">Name <span class="text-danger"
                                                                             title="This field is required">*</span></label>

                            <div class="col-sm-10">
                                <input type="text" title="Name" required=""
                                       placeholder="You can only enter the letter only" maxlength="70"
                                       class="form-control" name="name" id="name" value="">

                                <div class="text-danger"></div>
                                <p class="help-block"></p>

                            </div>
                        </div>
                        <div class="form-group header-group-0 " id="form-group-name" style="">
                            <label class="control-label col-sm-2">Category <span class="text-danger"
                                                                                 title="This field is required">*</span></label>

                            <div class="col-sm-10">
                                <select class="form-control select2-hidden-accessible" name="category_name"
                                        id="category_name">
                                    @if(!empty($categories))
                                        <option value="">Please select a category</option>
                                        @foreach($categories as $category)
                                            <option value="{{$category->id}}">{{$category->name}}</option>
                                        @endforeach
                                    @endif
                                </select>
                                <div class="text-danger"></div>
                                <p class="help-block"></p>

                            </div>
                        </div>
                        <div class="form-group header-group-0 " id="form-group-name" style="">
                            <label class="control-label col-sm-2">Sub Category <span class="text-danger"
                                                                                     title="This field is required">*</span></label>
                            <div class="col-sm-10">
                                <select class="form-control select2-hidden-accessible" required name="sub_category_name"
                                        id="sub_category_name">

                                </select>
                                <div class="text-danger"></div>
                                <p class="help-block"></p>

                            </div>
                        </div>
                        <div class="form-group header-group-0 " id="form-group-name" style="">
                            <label class="control-label col-sm-2">Brand/Accessory Type</label>

                            <div class="col-sm-10">
                                <select class="form-control select2-hidden-accessible" name="types"
                                        id="type">
                                    <option value="brand">Brand</option>
                                    <option value="Accessory Types">Accessory Type</option>
                                </select>
                                <div class="text-danger"></div>
                                <p class="help-block"></p>

                            </div>
                        </div>
                        <div class="form-group header-group-0 " id="form-group-name" style="">
                            <label class="control-label col-sm-2">Status<span class="text-danger"
                                                                              title="This field is required">*</span></label>

                            <div class="col-sm-10">
                                <select class="form-control select2-hidden-accessible" name="status" id="status">
                                    <option value="Publish">Publish</option>
                                    <option value="Unpublish">Unpublish</option>
                                    <option value="Draft">Draft</option>
                                </select>
                                <div class="text-danger"></div>
                                <p class="help-block"></p>

                            </div>
                        </div>
                    </div><!-- /.box-body -->

                    <div class="box-footer" style="background: #F5F5F5">

                        <div class="form-group">
                            <label class="control-label col-sm-2"></label>
                            <div class="col-sm-10">
                                @if($button_cancel && CRUDBooster::getCurrentMethod() != 'getDetail')
                                    @if(g('return_url'))
                                        <a href='{{g("return_url")}}' class='btn btn-default'><i
                                                    class='fa fa-chevron-circle-left'></i> {{trans("crudbooster.button_back")}}
                                        </a>
                                    @else
                                        <a href='{{CRUDBooster::mainpath("?".http_build_query(@$_GET)) }}'
                                           class='btn btn-default'><i
                                                    class='fa fa-chevron-circle-left'></i> {{trans("crudbooster.button_back")}}
                                        </a>
                                    @endif
                                @endif
                                @if(CRUDBooster::isCreate() || CRUDBooster::isUpdate())

                                    @if(CRUDBooster::isCreate() && $button_addmore==TRUE && $command == 'add')
                                        <input type="submit" name="submit"
                                               value='{{trans("crudbooster.button_save_more")}}'
                                               class='btn btn-success'>
                                    @endif

                                    @if($button_save && $command != 'detail')
                                        <input type="submit" name="submit" value='{{trans("crudbooster.button_save")}}'
                                               class='btn btn-success'>
                                    @endif

                                @endif
                            </div>
                        </div>


                    </div><!-- /.box-footer-->

                </form>

            </div>
        </div>
    </div><!--END AUTO MARGIN-->

@endsection
@section('scripts')
    <script>
        $(document).ready(function () {
            $("#category_name").on("change", function () {
    var category_id=$(this).val();
    jQuery.ajax({
        url:"{{route('ajax-request-sub-category')}}",
        data:{id:category_id},
        dataType:"html",
        success:function (data) {
            $("#sub_category_name").html(data);
        }
    })
            })
        })
    </script>
@stop
