<div class="container-fluid footer">
	<div class="container">
		<div class="clear_padding col-md-12">
			<p>Copy right 2018</p>
		</div>
	</div>
</div>